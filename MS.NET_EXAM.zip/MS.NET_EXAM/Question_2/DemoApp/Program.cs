﻿using Commonlib;
Console.WriteLine("Please Select Staff Type \nPress 1: Deatils of Full Time Staff \nPress 2: Details of Part Time Staff");

int n = int.Parse(Console.ReadLine());

switch(n)
{
    case 1:
        IList<FullTimeStaff> emp = Employee.GetPermanentEmployee();   // using IList
        foreach(var member in emp)
            member.PrintDetail();
            break;

    case 2:
        IList<PartTimeStaff> temp = Employee.GetTemporeryEmployee();
        foreach(var member in temp)
            member.PrintDetail();
            break;

    default:
    Console.WriteLine("Invalid Input Try Again");
    break;
    
    
}

class Employee       // inner class
{

   
public static IList<FullTimeStaff> GetPermanentEmployee()   
{
    var employee = new List<FullTimeStaff>();      //using List to store data
    employee.Add(new FullTimeStaff("Alok","Mumbai","Maintance",30000));
    employee.Add(new FullTimeStaff("Rishi","Pune","Sales",25000));
    employee.Add(new FullTimeStaff("Aditya","Bihar","HR",45000));    
    employee.Add(new FullTimeStaff("Ameya","Nashik","Devlopment",25000));
   
    return employee;
}
public static IList<PartTimeStaff> GetTemporeryEmployee()
{
    var employee = new List<PartTimeStaff>();     //using List to store data
    employee.Add(new PartTimeStaff("Rohit","Mumbai",200,50));
    employee.Add(new PartTimeStaff("Shubham","Pune",180,80));
    employee.Add(new PartTimeStaff("Shreyas","Satatra",120,20));
  
    return employee;
}

}