namespace Commonlib;    // namespace for avopiding name collision
public class FullTimeStaff : Staff    // inherit from class Staff
{
    
    public string Department { get; set; }

    public double Salary { get; set;}

    public FullTimeStaff(string Name, string Address, string Department,double Salary) : base(Name,Address)
    {
        this.Department = Department;
        this.Salary = Salary; 
    }

    public FullTimeStaff() : base()
    {    
        Department = "Maintance";
        Salary = 300000;
    }

    public  override void  PrintDetail()        //  ovveride method for disply data
    {
        Console.WriteLine("Name:{0}\tAddress:{1}\tDepartment:{2}\tSalary:{3}", Name,Address, Department, Salary);
    }
}