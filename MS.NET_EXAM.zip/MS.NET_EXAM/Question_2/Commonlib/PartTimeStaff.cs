namespace Commonlib;    // namespace for avopiding name collision
public class PartTimeStaff : Staff    // inherit from class Staff
{
    

    public int Hours { get; set; }

    public double RatePerHour { get; set;}

    public PartTimeStaff(string Name, string Address, int Hours,double RatePerHour) : base(Name,Address)
    {
        this.Hours = Hours;
        this.RatePerHour = RatePerHour; 
    }

    public PartTimeStaff() : base()
    {    
        Hours = 08;
        RatePerHour = 200;
    }

    public override void PrintDetail()    //  ovveride method for disply data
    {
        Console.WriteLine("Name:{0}\tAddress:{1}\tHours:{2}\tRate:{3}",Name, Address, Hours, RatePerHour);
    }
}