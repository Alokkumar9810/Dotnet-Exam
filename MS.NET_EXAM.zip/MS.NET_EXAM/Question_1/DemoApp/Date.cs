﻿namespace Demo;      // using namespace to avoid name collision

public class Date
{
    private int day;

    private int month;

    private int year;

    public Date(int day, int month, int year)  // parameterized counstructor
    {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public Date()    // parameterless constructor
    {
        day = 01;
        month = 01;
        year = 2001;
    }
    public int Day
    {
        get { return day; }
        set { day = value; }
    }

    public int Month
    {
        get { return month; }
        set { month = value; }
    }

    public int Year
    {
        get { return year; }
        set { year = value; }
    }
    
}
