namespace Demo;


public class Student
{
    private int id;

    private string name;

    public Date date;

    public int[] marks = new int[3];

    public Student(int id, string name, Date dateofbirth, int[] marks)
    {
        this.id = id;
        this.name = name;
        this.date = dateofbirth;
        this.marks =  marks;
    }

    public Student()
    {
        id = 01;
        name = "jack";
        date = new Date(01,01,2001);
        marks = new int[3]{10,20,30};
    }

    
    public int Id
    {
        get { return id; }
        set { id = value; }
    }

    public string Name
    {
        get { return name ; }
        set { name = value; }
    }

      
} 