using Demo;

int[] marks=new int[3]{80,92,85};
Date dob  = new Date(23,09,1996);
Student stud=new Student(01,"Alok",dob,marks);
Console.WriteLine("Student Id:{0}\t Student Name:{1}\t Student Dob:{2}/{3}/{4}",stud.Id,stud.Name,stud.date.Day,stud.date.Month,stud.date.Year);
Console.WriteLine("Marks of Student is:-Subject_01:{0}\t Subject_02:{1}\t Subject_03:{2}",stud.marks[0],stud.marks[1], stud.marks[2]);